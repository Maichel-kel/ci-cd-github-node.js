# ci-cd-github-nodejs

Repository untuk project CI/CD menggunakan GitHub Actions dan Node.js

## Fitur
- Automated testing
- Continuous deployment
- Notifikasi via Telegram

## Cara Menjalankan
```bash
npm install
npm test
contoh perubahan kecil
\nTest notifikasi
